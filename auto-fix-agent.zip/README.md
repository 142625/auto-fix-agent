# Auto Fix Agent

## Overview
An AI-powered agent that:
- Reads GitHub issues
- Generates bug fixes using LLM
- Commits code and creates PR automatically

## Usage
1. Fill config.py
2. Ensure git repo initialized
3. Run:

```bash
python main.py
```
