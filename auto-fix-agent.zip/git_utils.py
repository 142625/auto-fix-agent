import subprocess

def run(cmd):
    return subprocess.check_output(cmd, shell=True).decode()

def create_branch(branch):
    run(f"git checkout -b {branch}")

def commit_all(msg):
    run("git add .")
    run(f'git commit -m "{msg}"')

def push(branch):
    run(f"git push origin {branch}")
