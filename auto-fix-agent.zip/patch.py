def apply_patch(file_path, new_code):
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(new_code)
