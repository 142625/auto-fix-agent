import requests
from config import *
from llm import generate_fix
from git_utils import *
from patch import apply_patch

def get_issues():
    url = f"https://api.github.com/repos/{REPO}/issues"
    headers = {"Authorization": f"token {GITHUB_TOKEN}"}
    return requests.get(url, headers=headers).json()

def create_pr(branch, title):
    url = f"https://api.github.com/repos/{REPO}/pulls"
    headers = {"Authorization": f"token {GITHUB_TOKEN}"}
    data = {
        "title": f"Fix: {title}",
        "head": branch,
        "base": BASE_BRANCH,
        "body": "Auto-generated fix by AI Agent"
    }
    requests.post(url, headers=headers, json=data)

def main():
    issues = get_issues()
    issue = issues[0]

    title = issue["title"]
    body = issue["body"]

    file_path = "app.py"
    with open(file_path, "r") as f:
        code = f.read()

    print("Generating fix...")
    fixed_code = generate_fix(title, body, code)

    branch = "auto-fix-branch"
    create_branch(branch)

    apply_patch(file_path, fixed_code)

    commit_all(f"fix: {title}")
    push(branch)

    create_pr(branch, title)

    print("PR created!")

if __name__ == "__main__":
    main()
