import requests
from config import OPENAI_API_KEY

def generate_fix(issue_title, issue_body, code_context):
    prompt = f"""
You are a senior engineer. Fix the following bug.

Issue:
{issue_title}
{issue_body}

Code:
{code_context}

Return the full fixed code.
"""

    response = requests.post(
        "https://api.openai.com/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {OPENAI_API_KEY}",
            "Content-Type": "application/json"
        },
        json={
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": prompt}]
        }
    )

    return response.json()["choices"][0]["message"]["content"]
