GITHUB_TOKEN = "your_github_token"
REPO = "username/repo"
OPENAI_API_KEY = "your_openai_api_key"
BASE_BRANCH = "main"
